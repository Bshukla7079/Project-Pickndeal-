class Profile{
    businessName = "#business_name"
    Services = ".multiselect"
    Services1 = "#multiselect-option-56"
    Services2 = "#multiselect-option-71"
    address = "#address"
    address2 = "input[placeholder='Enter your address']"
    country = ".vs__search"
    countryname = "#vs1__combobox"
    state = "#vs2__listbox"
    city = "#vs3__combobox"
    zip = '#zip'

}

export default Profile
class SignIn {

    signinTitle = "h1[class='text-start']"
    signinparagraph = "p[class='text-start']"
    username = "#userName"
    password = "#password"
    SigninButton = ".btn-primary"
    message = ".alert-success"
    signupLink = ".links"
}
export default SignIn
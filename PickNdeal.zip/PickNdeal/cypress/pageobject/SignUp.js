class SignUp {
    profile1 = 'div[class="userSelect selected"]'
    profile2 = 'div[class="userSelect"]'
    firstname = '#firstName'
    lastname = '#lastName'
    email = '#emailaddress'
    phoneNo = '#phoneNumber'
    password = '#password'
    cPassword = '#password_confirmation'
    signUpButton = '.btn-primary'
    registeredMessage = '.alert-success'
    loginLink = '.login-link'
}

export default SignUp
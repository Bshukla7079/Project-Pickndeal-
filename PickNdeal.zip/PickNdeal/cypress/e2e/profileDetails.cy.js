import Profile from "../pageobject/profile";
describe('ProfileDetails', ()=>{

     var locator = new Profile();
    it('TC_201,TC_202,TC_203_TC_204',()=>{
  
      cy.SignIn("ansh14@yopmail.com", "Admin@123");
      cy.get(locator.businessName).type("test");
      cy.get(locator.Services).find(locator.Services1).contains(" Auto Service").click({force: true});
      cy.get(locator.Services).find(locator.Services2).contains(" Party decoration").click({force: true});
      cy.get(locator.address).type("GGIC Roade Gaucher")
      cy.get(locator.address2).type('CHANDIGARH UNIVERSITY, NH-05, Ludhiana - Chandigarh State Hwy, Punjab 140413, India');
      //cy.contains("CHANDIGARH UNIVERSITY, NH-05, Ludhiana - Chandigarh State Hwy, Punjab 140413, India").click();

      cy.get("input[aria-labelledby='vs1__combobox']").click();
      cy.get(locator.country).find(locator.countryname).contains("India").click({force: true});
      cy.get(locator.country).find(locator.state).contains("Bihar").click({force: true});
      cy.get(locator.country).find(locator.city).contains("Arrah").click({force: true})
      cy.get(locator.zip).type('123456');
      
  
  
    })
  
  })
import SignIn from "../pageobject/SignIn"
describe('SignIn', ()=>{

   beforeEach(function(){
      cy.fixture('SignIn').then(function(data){
        this.data = data
     }) 
  })

    beforeEach(function(){

        cy.visit(this.data.url);
        cy.title().should('be.equal','PickNDeal');
     
     })

     it('Verify that user is able to navigate on signIn page.',()=>{
        cy.contains('Sign In').should('be.visible');
    })
      
    var locator = new SignIn();

     it('Verify that user is able to see Sign In title on the top of the page. ',function(){
        cy.get(locator.signinTitle).should('be.visible').should('contain.text', 'Sign In');
        cy.get(locator.signinparagraph).should('be.visible').should('contain.text', this.data.paragraph);

    })

  it.skip('TC_104 TC_105 TC_106 TC_107 TC_108',function(){
      cy.get(locator.username).should('be.visible').type(this.data.username);
      cy.get(locator.password).should('be.visible').type(this.data.password);
      cy.get(locator.SigninButton).click();
      cy.contains('Home').should('be.visible');
  })

  it('TC_109 TC_110 TC_111 TC_112 TC_113 tc_114 TC_115 TC_116',function(){
   cy.contains('Forgot your password?').click();
   cy.url().should('eq', this.data.forgotURL);
   cy.get(locator.username).type(this.data.username)
   cy.contains('Submit').click();
   cy.contains('Sign In').should('be.visible');
   cy.get(locator.message).should('be.visible');
   
})

it('TC_117 TC_118 TC_119 TC_120 TC_121 ',function(){
   cy.contains('Sign Up').should('be.visible');
   cy.get(locator.signupLink).should('contain.text', this.data.signupMessage);
   cy.get(locator.signupLink).should('contain.text', 'Sign Up')
   cy.contains('Sign Up').click();
   cy.contains('Enter your details below').should('be.visible');
   
})

   })

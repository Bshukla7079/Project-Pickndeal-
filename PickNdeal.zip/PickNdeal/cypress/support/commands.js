// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

import SignIn from "../pageobject/SignIn"
var locator = new SignIn();

Cypress.Commands.add('SignIn', function(username , password){

        cy.visit("https://pickndeal.oidea.online/laravel_app/public/user/login");
        cy.title().should('be.equal','PickNDeal');
        cy.get(locator.username).should('be.visible').type(username);
        cy.get(locator.password).should('be.visible').type(password);
        cy.get(locator.SigninButton).click();
        //cy.contains('Home').should('be.visible');
    
  
})